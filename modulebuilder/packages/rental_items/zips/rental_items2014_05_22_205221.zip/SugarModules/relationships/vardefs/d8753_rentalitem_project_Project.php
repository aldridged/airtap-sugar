<?php
// created: 2014-05-22 20:52:21
$dictionary["Project"]["fields"]["d8753_rentalitem_project"] = array (
  'name' => 'd8753_rentalitem_project',
  'type' => 'link',
  'relationship' => 'd8753_rentalitem_project',
  'source' => 'non-db',
  'module' => 'd8753_rentalitem',
  'bean_name' => 'd8753_rentalitem',
  'side' => 'right',
  'vname' => 'LBL_D8753_RENTALITEM_PROJECT_FROM_D8753_RENTALITEM_TITLE',
);
