<?php
 // created: 2014-05-22 20:51:57
$layout_defs["Project"]["subpanel_setup"]['d8753_rentalitem_project'] = array (
  'order' => 100,
  'module' => 'd8753_rentalitem',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_D8753_RENTALITEM_PROJECT_FROM_D8753_RENTALITEM_TITLE',
  'get_subpanel_data' => 'd8753_rentalitem_project',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
